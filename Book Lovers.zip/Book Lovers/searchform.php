<form role="search" method="get" id="searchform" action="<?php echo home_url('/');?>">
<div><label class="screen-reader-text" for="s">Search for:</label>
<input type="div" value="" name="s" id="s" />
<input type="submit" id="search submit" value="search"/></div>
</form>